﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Okosreceptkonyv.Users
{
    internal class User
    {
        public int ID { get; set; }
        public string Nev { get; set; }
        public string Jelszo { get; set; }
        public int Aktiv { get; set; }

    }
}
