﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Dapper;
using Okosreceptkonyv.Connection;
using Okosreceptkonyv.UnitsOfMeasure;

namespace Okosreceptkonyv
{
    /// <summary>
    /// Interaction logic for HozzavaloHozzadasWindow.xaml
    /// </summary>
    public partial class HozzavaloHozzadasWindow : Window
    {
        public HozzavaloHozzadasWindow()
        {
            InitializeComponent();

            using (var kapcsolat = connection.GetDbConnection())
            {
                var mertekegysegek = kapcsolat.Query<UnitOfMeasure>("USE okosrecetkonyv select [Nev] from [MERTEKEGYSEG]");
                dropdownComboBox.ItemsSource = mertekegysegek;
                dropdownComboBox.DisplayMemberPath = "Nev";
            }

        }

        private void ToggleButton_Click(object sender, RoutedEventArgs e)
        {
            if (tb_ingridient.Text == "")
            {
                MessageBox.Show("Adjon meg nevet a hozzávalóhoz!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (tb_quantity.Text == "" || !int.TryParse(tb_quantity.Text, out _))
            {
                MessageBox.Show("A mennyiség mező üres vagy nem szám!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (dropdownComboBox.SelectedItem == null)
            {
                MessageBox.Show("Nincs mértékegység kiválasztva!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                var kivalasztott = (UnitOfMeasure)dropdownComboBox.SelectedItem;
                string hozzavalo = tb_ingridient.Text + " " + tb_quantity.Text + " " + kivalasztott.Nev;
                this.Close();
            }
        }

    }
}
