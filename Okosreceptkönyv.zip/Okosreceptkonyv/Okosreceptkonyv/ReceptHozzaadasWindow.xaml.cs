﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Okosreceptkonyv.Connection;
using Okosreceptkonyv.Categories;
using Dapper;
using Okosreceptkonyv.UnitsOfMeasure;

using Microsoft.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;

namespace Okosreceptkonyv
{
    /// <summary>
    /// Interaction logic for ReceptHozzaadasWindow.xaml
    /// </summary>
    public partial class ReceptHozzaadasWindow : Window
    {
        string kepstring;
        int eredetimeret;
        List<string> ingridients_list = new List<string>();
        List<int> ingridients_unit_quantity_list = new List<int>();
        List<int> ingridients_unit_id_list = new List<int>();
        List<string> ingridients_add_list = new List<string>();
        List<string> categories_list;
        List<int> categories_id_list;
        List<string> unitofmeasure_list;
        List<int> unitofmeasure_id_list;

        public ReceptHozzaadasWindow()
        {
            InitializeComponent();

            using (var kapcsolat = connection.GetDbConnection())
            {
                var mertekegysegek = kapcsolat.Query<UnitOfMeasure>("USE okosrecetkonyv select * from [MERTEKEGYSEG]");
                unitofmeasure_id_list = new List<int>();
                unitofmeasure_list = new List<string>();
                foreach (var unitofmeasure in mertekegysegek)
                {
                    unitofmeasure_id_list.Add(unitofmeasure.ID);
                    unitofmeasure_list.Add(unitofmeasure.Nev);
                }
                dropdownComboBox.ItemsSource = unitofmeasure_list;

                var categories = kapcsolat.Query<Category>("USE okosrecetkonyv select * from [KATEGORIA]");
                categories_list = new List<string>();
                categories_id_list = new List<int>();
                foreach (var category in categories)
                {
                    categories_id_list.Add(category.ID);
                    categories_list.Add(category.Kategorianev);
                }
                multipleChoiceListBox.ItemsSource = categories_list;
                eredetimeret = categories_list.Count;
            }
        }

        private void btn_navigation_Click(object sender, RoutedEventArgs e)
        {
            if (btn_search.Visibility == Visibility.Visible && btn_upload.Visibility == Visibility.Visible)
            {
                btn_search.Visibility = Visibility.Collapsed;
                btn_upload.Visibility = Visibility.Collapsed;
            }
            else
            {
                btn_search.Visibility = Visibility.Visible;
                btn_upload.Visibility = Visibility.Visible;
            }
        }

        private void btn_search_Click(object sender, RoutedEventArgs e)
        {
            MainWindow search_window = new MainWindow();
            search_window.Show();
            this.Close();
        }

        private void btn_upload_Click(object sender, RoutedEventArgs e)
        {
            ReceptHozzaadasWindow receptHozzadas_window = new ReceptHozzaadasWindow();
            receptHozzadas_window.Show();
            this.Close();
        }

        private void btn_navToMain_Click(object sender, RoutedEventArgs e)
        {
            MainWindow search_window = new MainWindow();
            search_window.Show();
            this.Close();
        }

        private void btn_ingridient_Click(object sender, RoutedEventArgs e)
        {
            if (ingridient_border.Visibility != Visibility.Visible)
            {
                ingridient_border.Visibility = Visibility.Visible;
            } else
            {
                tb_quantity.Text = "Mennyiség"; dropdownComboBox.SelectedItem = null; tb_ingridient.Text = "Hozzávaló neve";
                ingridient_border.Visibility = Visibility.Hidden;
            }
        }

        private void btn_add_ingridient_Click(object sender, RoutedEventArgs e)
        {
            if (tb_ingridient.Text == "" || int.TryParse(tb_ingridient.Text, out _) || ingridients_list.Contains(tb_ingridient.Text))
            {
                System.Windows.MessageBox.Show("Adjon meg nevet a hozzávalóhoz!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (tb_quantity.Text == "" || !int.TryParse(tb_quantity.Text, out _))
            {
                System.Windows.MessageBox.Show("A mennyiség mező üres, vagy nem szám!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (dropdownComboBox.SelectedItem == null)
            {
                System.Windows.MessageBox.Show("Nincs mértékegység kiválasztva!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                ingridients_add_list.Add(tb_quantity.Text + " " + dropdownComboBox.SelectedItem.ToString() + " " + tb_ingridient.Text.ToLower());
                ingidient_list.ItemsSource = ingridients_add_list;
                ingidient_list.Items.Refresh();
                ingridients_list.Add(tb_ingridient.Text.ToLower());
                ingridients_unit_quantity_list.Add(int.Parse(tb_quantity.Text));
                ingridients_unit_id_list.Add(unitofmeasure_id_list[unitofmeasure_list.IndexOf(dropdownComboBox.SelectedItem.ToString())]);
                tb_quantity.Text = ""; dropdownComboBox.SelectedItem = null; tb_ingridient.Text = "";
                ingridient_border.Visibility = Visibility.Hidden;
            }
        }

        private void btn_save_Click(object sender, RoutedEventArgs e)
        {
            if (tb_recipeName.Text == "")
            {
                System.Windows.MessageBox.Show("Adjon nevet a receptnek!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (ingidient_list.Items.Count < 3)
            {
                System.Windows.MessageBox.Show("Legalább 3 hozzávalót hozzá kell adni a recepthez!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (multipleChoiceListBox.SelectedItems.Count == 0)
            {
                System.Windows.MessageBox.Show("Válasszon ki legalább egy kategóriát!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (tb_description.Text.Length <= 50)
            {
                System.Windows.MessageBox.Show("A leírásnak minimum 50 karakternek kell lennie!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                using (var kapcsolat = (SqlConnection)connection.GetDbConnection())
                {
                    string query;
                    int kepid = 1;
                    //kép hozzáadása az adatbázisba, ha választottunk képet
                    if (kepstring != null)
                    {
                        query = @"USE okosrecetkonyv INSERT INTO [KEP] (Kep) VALUES (@Kep)";
                        using (SqlCommand command = new SqlCommand(query, kapcsolat))
                        {
                            command.Parameters.AddWithValue("@Kep", kepstring);
                            command.ExecuteNonQuery();
                        }
                        var ujkepid = kapcsolat.Query<int>("USE okosrecetkonyv SELECT TOP 1 [ID] from [KEP] ORDER BY [ID] DESC");
                        foreach (var item in ujkepid)
                        {
                            kepid = item;
                        }
                    }

                    //recept hozzáadása az adatbázisba
                    query = @"USE okosrecetkonyv INSERT INTO [RECEPT] (Kep_ID, Nev, Leiras) VALUES (@Kep_ID, @Nev, @Leiras)";
                    using (SqlCommand command = new SqlCommand(query, kapcsolat))
                    {
                        command.Parameters.AddWithValue("@Kep_ID", kepid);
                        command.Parameters.AddWithValue("@Nev", tb_recipeName.Text);
                        command.Parameters.AddWithValue("@Leiras", tb_description.Text);
                        command.ExecuteNonQuery();
                    }
                    var ujreceptid = kapcsolat.Query<int>("USE okosrecetkonyv SELECT TOP 1 [ID] from [RECEPT] ORDER BY [ID] DESC");
                    int receptid = 0;
                    foreach (var item in ujreceptid)
                    {
                        receptid = item;
                    }

                    //kategória hozzáadás adatbázisba
                    foreach (var item in multipleChoiceListBox.SelectedItems)
                    {
                        //ha volt ilyen kategória
                        if (categories_list.IndexOf((string)item) < eredetimeret)
                        {
                            query = @"USE okosrecetkonyv INSERT INTO [RECEPT_KATEGORIA] VALUES (@Recept_ID, @Kategoria_ID)";
                            using (SqlCommand command = new SqlCommand(query, kapcsolat))
                            {
                                command.Parameters.AddWithValue("@Recept_ID", receptid);
                                command.Parameters.AddWithValue("@Kategoria_ID", categories_id_list[categories_list.IndexOf((string)item)]);
                                command.ExecuteNonQuery();
                            }
                        } else //ha nem volt ilyen kategória
                        {
                            query = @"USE okosrecetkonyv INSERT INTO [KATEGORIA] (Kategorianev) VALUES (@Kategoria_nev)";
                            using (SqlCommand command = new SqlCommand(query, kapcsolat))
                            {
                                command.Parameters.AddWithValue("@Kategoria_nev", item);
                                command.ExecuteNonQuery();
                            }
                            var ujcategoryid = kapcsolat.Query<int>("USE okosrecetkonyv SELECT TOP 1 [ID] from [KATEGORIA] ORDER BY [ID] DESC");
                            int categoryid = 0;
                            foreach (var id in ujcategoryid)
                            {
                                categoryid = id;
                            }
                            query = @"USE okosrecetkonyv INSERT INTO [RECEPT_KATEGORIA] VALUES (@Recept_ID, @Kategoria_ID)";
                            using (SqlCommand command = new SqlCommand(query, kapcsolat))
                            {
                                command.Parameters.AddWithValue("@Recept_ID", receptid);
                                command.Parameters.AddWithValue("@Kategoria_ID", categoryid);
                                command.ExecuteNonQuery();
                            }
                        }
                    }

                    //hozzávaló hozzáadása az adatbázisba
                    foreach (var ingridient_item in ingridients_list)
                    {
                        query = "USE okosrecetkonyv SELECT ID FROM [HOZZAVALOK] WHERE Nev LIKE '" + ingridient_item + "'";
                        var ujhozzavaloid = kapcsolat.Query<int>(query);
                        int hozzavaloid = 0;
                        foreach (var item in ujhozzavaloid)
                        {
                            hozzavaloid = item;
                        }
                        //ha van olyan hozzávaló
                        if (hozzavaloid != 0)
                        {
                            query = @"USE okosrecetkonyv INSERT INTO [RECEPT_HOZZAVALO] VALUES (@Recept_ID, @Hozzavalok_ID, @Mertekegyseg_ID, @Mennyiseg)";
                            using (SqlCommand command = new SqlCommand(query, kapcsolat))
                            {
                                command.Parameters.AddWithValue("@Recept_ID", receptid);
                                command.Parameters.AddWithValue("@Hozzavalok_ID", hozzavaloid);
                                command.Parameters.AddWithValue("@Mertekegyseg_ID", ingridients_unit_id_list[ingridients_list.IndexOf(ingridient_item)]);
                                command.Parameters.AddWithValue("@Mennyiseg", ingridients_unit_quantity_list[ingridients_list.IndexOf(ingridient_item)]);
                                command.ExecuteNonQuery();
                            }
                        }
                        else //ha nincs olyan
                        {
                            query = @"USE okosrecetkonyv INSERT INTO [HOZZAVALOK] (Nev) VALUES (@Nev)";
                            using (SqlCommand command = new SqlCommand(query, kapcsolat))
                            {
                                command.Parameters.AddWithValue("@Nev", ingridient_item);
                                command.ExecuteNonQuery();
                            }

                            var ujingridientid = kapcsolat.Query<int>("USE okosrecetkonyv SELECT TOP 1 [ID] from [HOZZAVALOK] ORDER BY [ID] DESC");
                            int ingridientid = 0;
                            foreach (var id in ujingridientid)
                            {
                                ingridientid = id;
                            }

                            query = @"USE okosrecetkonyv INSERT INTO [RECEPT_HOZZAVALO] VALUES (@Recept_ID, @Hozzavalok_ID, @Mertekegyseg_ID, @Mennyiseg)";
                            using (SqlCommand command = new SqlCommand(query, kapcsolat))
                            {
                                command.Parameters.AddWithValue("@Recept_ID", receptid);
                                command.Parameters.AddWithValue("@Hozzavalok_ID", ingridientid);
                                command.Parameters.AddWithValue("@Mertekegyseg_ID", ingridients_unit_id_list[ingridients_list.IndexOf(ingridient_item)]);
                                command.Parameters.AddWithValue("@Mennyiseg", ingridients_unit_quantity_list[ingridients_list.IndexOf(ingridient_item)]);
                                command.ExecuteNonQuery();
                            }
                        }
                    }
                }
                
                MainWindow search_window = new MainWindow();
                search_window.Show();
                this.Close();
            }
        }

        private void ListBoxItem_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is ListBoxItem listBoxItem)
            {
                listBoxItem.IsSelected = !listBoxItem.IsSelected;
            }
        }

        private void ImageMouseLeftButton_UploadImage(object sender, MouseButtonEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Képfájlok|*.jpg;*.jpeg;*.png;*.bmp";

            DialogResult result = openFileDialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                string imagePath = openFileDialog.FileName;

                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(imagePath);
                bitmap.EndInit();
                picture.Source = bitmap;

                byte[] imageBytes;
                using (MemoryStream stream = new MemoryStream())
                {
                    BitmapEncoder encoder = new JpegBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(bitmap));
                    encoder.Save(stream);
                    imageBytes = stream.ToArray();
                }

                kepstring = Convert.ToBase64String(imageBytes);
            }

        }

        private void OnKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                if (ingredientTextBox.Text == "" || categories_list.Contains(ingredientTextBox.Text.ToLower()))
                {
                    System.Windows.MessageBox.Show("A mező üres, vagy már tartalmazza az adott kategóriát!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    categories_list.Add((string)ingredientTextBox.Text.ToLower());
                    multipleChoiceListBox.Items.Refresh();
                    ingredientTextBox.Text = "";
                }
            }
        }

		private void btn_exit_Click(object sender, RoutedEventArgs e)
		{
			App.Current.Shutdown();
		}

		private void btn_close_Click(object sender, RoutedEventArgs e)
		{
            tb_quantity.Text = ""; dropdownComboBox.SelectedItem = null; tb_ingridient.Text = "";
            ingridient_border.Visibility = Visibility.Hidden;
		}
    }
}
