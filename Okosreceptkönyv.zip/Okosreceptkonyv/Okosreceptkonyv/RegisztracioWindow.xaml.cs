﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Dapper;
using Microsoft.Data.SqlClient;
using Okosreceptkonyv.Connection;
using Okosreceptkonyv.Users;
using System.Data.SqlClient;

namespace Okosreceptkonyv
{
    /// <summary>
    /// Interaction logic for RegisztracioWindow.xaml
    /// </summary>
    public partial class RegisztracioWindow : Window
    {
        public RegisztracioWindow()
        {
            InitializeComponent();
        }

		private void btn_navToBejelentkezes_Click(object sender, RoutedEventArgs e)
		{
			BejelentkezesWindow bej_felulet = new BejelentkezesWindow();
			bej_felulet.Show();
			this.Close();
		}

		private void btn_navigation_Click(object sender, RoutedEventArgs e)
		{
			if (btn_search.Visibility == Visibility.Visible && btn_upload.Visibility == Visibility.Visible)
			{
				btn_search.Visibility = Visibility.Collapsed;
				btn_upload.Visibility = Visibility.Collapsed;
			}
			else
			{
				btn_search.Visibility = Visibility.Visible;
				btn_upload.Visibility = Visibility.Visible;
			}
		}

		private void btn_upload_Click(object sender, RoutedEventArgs e)
		{
			ReceptHozzaadasWindow receptHozzadas_window = new ReceptHozzaadasWindow();
			receptHozzadas_window.Show();
			this.Close();
		}

		private void btn_search_Click(object sender, RoutedEventArgs e)
		{
			MainWindow search_window = new MainWindow();
			search_window.Show();
			this.Close();
		}

        private void btn_register_Click(object sender, RoutedEventArgs e)
        {
            if (pb_password.Password != pb_passwordagain.Password)
            {
                MessageBox.Show("A két jelszó nem egyezik meg!", "Hibás jelszó", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                string felhasznalonev = tb_username.Text;
                string jelszo = pb_password.Password;

                using (var kapcsolat = connection.GetDbConnection())
                {
                    var marletezikilyenfelhasznalo = kapcsolat.QueryFirstOrDefault<User>("USE okosrecetkonyv SELECT * FROM FELHASZNALO WHERE Nev = @Nev AND Aktiv = 1",
                                                                    new { Nev = tb_username.Text });

                    if (marletezikilyenfelhasznalo != null)
                    {
                        tb_username.Text = "";
                        pb_password.Password = "";
                        pb_passwordagain.Password = "";
                        MessageBox.Show("Már létezik ilyen felhasználó!", "Foglalt felhasználó név", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        string query = "USE okosrecetkonyv INSERT INTO FELHASZNALO (Nev, Jelszo, Aktiv) VALUES (@Nev,@Jelszo,1)";
                        SqlCommand command = new SqlCommand(query);
                        command.Parameters.AddWithValue("@Nev", felhasznalonev);
                        command.Parameters.AddWithValue("@Jelszo", jelszo); // Kis 'j' betűs paraméter helyett nagy 'J' betűs
                        command.Connection = (SqlConnection)kapcsolat;
                        command.ExecuteNonQuery();
                        MessageBox.Show("Sikeres Regisztráció", "NAGY Siker!", MessageBoxButton.OK);
                        BejelentkezesWindow bej_felulet = new BejelentkezesWindow();
                        bej_felulet.Show();
                        this.Close();
                    }
                }
            }


        }

        private void tb_username_GotFocus(object sender, RoutedEventArgs e)
        {
            if (tb_username.Text == "Felhasználónév")
            {
                tb_username.Text = "";
            }
        }

        private void tb_username_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_username.Text))
            {
                tb_username.Text = "Felhasználónév";
            }
        }

        private void pb_password_GotFocus(object sender, RoutedEventArgs e)
        {
            if (pb_password.Password == "jelszó")
            {
                pb_password.Password = "";
            }
        }

        private void pb_password_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(pb_password.Password))
            {
                pb_password.Password = "jelszó";
            }
        }

        private void pb_passwordagain_GotFocus(object sender, RoutedEventArgs e)
        {
            if (pb_passwordagain.Password == "jelszó")
            {
                pb_passwordagain.Password = "";
            }
        }

        private void pb_passwordagain_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(pb_passwordagain.Password))
            {
                pb_passwordagain.Password = "jelszó";
            }
        }

		private void btn_exit_Click(object sender, RoutedEventArgs e)
		{
            Application.Current.Shutdown();
        }
    }
}
