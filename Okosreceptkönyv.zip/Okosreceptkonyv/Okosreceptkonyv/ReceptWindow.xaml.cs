﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using Dapper;
using Okosreceptkonyv.Connection;
using Microsoft.Data.SqlClient;
using System.Reflection.PortableExecutable;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.IO;

namespace Okosreceptkonyv
{
	/// <summary>
	/// Interaction logic for ReceptWindow.xaml
	/// </summary>
	public partial class ReceptWindow : Window
	{
        public String bereceptNeve;
        public String befelhasznaloNeve;

        public ReceptWindow(String receptNeve, String felhasznaloNeve)
		{
			InitializeComponent();

            bereceptNeve = receptNeve;
            befelhasznaloNeve = felhasznaloNeve;
            ReceptAdatkezeles receptAdatkezeles = new ReceptAdatkezeles();
            ReceptAdatok receptAdatok = receptAdatkezeles.GetReceptAdatok(receptNeve);
            FillListViewWithVelemenyek(receptNeve);
            recipe_name.Content = receptNeve;
            tb_description.Text = receptAdatok.Leiras;
            ListView myListView = this.FindName("Hozzavalok") as ListView;

            myListView.Items.Clear();

            
            for (int i = 0; i < receptAdatok.Hozzavalok.Count; i++)
            {
                ListViewItem listViewItem = new ListViewItem();

                if (receptAdatok.Hozzavalok[i].Mennyiseg!=0)
                {
                    listViewItem.Content = $"{receptAdatok.Hozzavalok[i].Nev}  {receptAdatok.Hozzavalok[i].Mennyiseg}  {receptAdatok.Hozzavalok[i].Mertekegyseg}";
                }
                else
                {
                    listViewItem.Content = $"{receptAdatok.Hozzavalok[i].Nev} {receptAdatok.Hozzavalok[i].Mertekegyseg}";
                }


                myListView.Items.Add(listViewItem);
            }
            DisplayImageFromDatabase("Mac and Cheese");


        }

        private void FillListViewWithVelemenyek(string receptNev)
        {
            ListView velemenylistview = this.FindName("vélemények") as ListView;
            velemenylistview.Items.Clear();
            if (velemenylistview != null)
            {
                velemenylistview.Items.Clear();

                var velemenyek = GetVelemenyekForRecept(receptNev);

                if (velemenyek != null && velemenyek.Any())
                {
                    foreach (var velemeny in velemenyek)
                    {
                        ListViewItem listViewItem = new ListViewItem();
                        listViewItem.Content = $"{velemeny.FelhasznaloNev}: {velemeny.Ertekeles} pont";
                        velemenylistview.Items.Add(listViewItem);
                    }
                }
                else
                {
                    ListViewItem listViewItem = new ListViewItem();
                    listViewItem.Content = "Nincsenek vélemények";
                    velemenylistview.Items.Add(listViewItem);
                }
            }

        }
        private List<Velemeny> GetVelemenyekForRecept(string receptNev)
        {
            List<Velemeny> velemenyek = new List<Velemeny>();

            using (var kapcsolat = connection.GetDbConnection())
            {
                string velemenyekQuery = @"use Okosrecetkonyv SELECT F.Nev AS FelhasznaloNev, E.Ertekeles AS Ertekeles
                                   FROM RECEPT R
                                   LEFT JOIN ERTEKELES E ON R.ID = E.Recept_ID
                                   LEFT JOIN FELHASZNALO F ON E.Felhasznalo_ID = F.ID
                                   WHERE R.Nev = @ReceptNev";

                //kapcsolat.Open();

                using (var command = new SqlCommand(velemenyekQuery, (SqlConnection)kapcsolat))
                {
                    command.Parameters.AddWithValue("@ReceptNev", receptNev);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            if (!reader.IsDBNull(reader.GetOrdinal("Ertekeles")))
                            {
                                Velemeny velemeny = new Velemeny
                                {
                                    FelhasznaloNev = reader["FelhasznaloNev"].ToString(),
                                    Ertekeles = Convert.ToDouble(reader["Ertekeles"])
                                };
                                velemenyek.Add(velemeny);
                            }

                        }
                    }
                }
            }

            return velemenyek;
        }

        public class Velemeny
        {
            public string FelhasznaloNev { get; set; }
            public double Ertekeles { get; set; }
        }

        public class ReceptAdatok
        {
            public string Leiras { get; set; }
            public string Kategoria { get; set; }
            public List<Hozzavalo> Hozzavalok { get; set; }
        }

        public class Hozzavalo
        {
            public string Nev { get; set; }
            public int Mennyiseg { get; set; }
            public string Mertekegyseg { get; set; }
        }

        public class ReceptAdatkezeles
        {
            public ReceptAdatok GetReceptAdatok(string receptNev)
            {
                ReceptAdatok receptAdatok = new ReceptAdatok();
                receptAdatok.Hozzavalok = new List<Hozzavalo>();

                using (var kapcsolat = connection.GetDbConnection())
                {
                    string leirasQuery = "Use okosrecetkonyv SELECT Leiras FROM RECEPT WHERE Nev = @ReceptNev;";
                    string kategoriaQuery = "Use okosrecetkonyv SELECT K.Kategorianev AS ReceptKategoria FROM RECEPT R LEFT JOIN RECEPT_KATEGORIA RK ON R.ID = RK.Recept_ID LEFT JOIN KATEGORIA K ON RK.Kategoria_ID = K.ID WHERE R.Nev = @ReceptNev;";
                    string hozzavaloQuery = "Use okosrecetkonyv SELECT H.Nev AS HozzavaloNev, RH.Mennyiseg, M.Nev AS Mertekegyseg FROM RECEPT R LEFT JOIN RECEPT_HOZZAVALO RH ON R.ID = RH.Recept_ID LEFT JOIN HOZZAVALOK H ON RH.Hozzavalok_ID = H.ID LEFT JOIN MERTEKEGYSEG M ON RH.Mertekegyseg_ID = M.ID WHERE R.Nev = @ReceptNev;";

                    using (var command = new SqlCommand(leirasQuery, (SqlConnection)kapcsolat))
                    {
                        command.Parameters.AddWithValue("@ReceptNev", receptNev);
                        //kapcsolat.Open();
                        receptAdatok.Leiras = (string)command.ExecuteScalar();
                    }

                    using (var command = new SqlCommand(kategoriaQuery, (SqlConnection)kapcsolat))
                    {
                        command.Parameters.AddWithValue("@ReceptNev", receptNev);
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                receptAdatok.Kategoria = reader["ReceptKategoria"].ToString();
                            }
                        }
                    }

                    using (var command = new SqlCommand(hozzavaloQuery, (SqlConnection)kapcsolat))
                    {
                        command.Parameters.AddWithValue("@ReceptNev", receptNev);
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string hozzavaloNev = reader["HozzavaloNev"] != DBNull.Value ? reader["HozzavaloNev"].ToString() : null;
                                int mennyiseg = reader["Mennyiseg"] != DBNull.Value ? Convert.ToInt32(reader["Mennyiseg"]) : 0;
                                string mertekegyseg = reader["Mertekegyseg"] != DBNull.Value ? reader["Mertekegyseg"].ToString() : null;

                                Hozzavalo hozzavalo = new Hozzavalo
                                {
                                    Nev = hozzavaloNev,
                                    Mennyiseg = mennyiseg,
                                    Mertekegyseg = mertekegyseg
                                };
                                receptAdatok.Hozzavalok.Add(hozzavalo);
                            }
                        }
                    }
                }

                return receptAdatok;
            }
        }





        public void DisplayImageFromDatabase(string recipeName)
        {
            string recipeQuery = @"USE Okosrecetkonyv;
                           DECLARE @KepID INT;
                           DECLARE @ReceptNev NVARCHAR(100) = @RecipeName;

                           SELECT @KepID=Kep_ID
                           FROM RECEPT
                           WHERE Nev = @ReceptNev;

                           SELECT Kep
                           FROM KEP
                           WHERE ID = @KepID;";

            using (var kapcsolat = connection.GetDbConnection())
            {

                using (var command = new SqlCommand(recipeQuery, (SqlConnection)kapcsolat))
                {
                    command.Parameters.AddWithValue("@RecipeName", recipeName);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string base64Image = reader["Kep"].ToString();

                            if (!string.IsNullOrEmpty(base64Image))
                            {
                                byte[] imageBytes = Convert.FromBase64String(base64Image);

                                BitmapImage bitmap = new BitmapImage();
                                bitmap.BeginInit();
                                bitmap.StreamSource = new MemoryStream(imageBytes);
                                bitmap.EndInit();

                                picture.Source = bitmap;
                            }
                        }
                    }
                }
            }
        }










        private void btn_navigation_Click(object sender, RoutedEventArgs e)
		{
			if (btn_search.Visibility == Visibility.Visible && btn_upload.Visibility == Visibility.Visible)
			{
				btn_search.Visibility = Visibility.Collapsed;
				btn_upload.Visibility = Visibility.Collapsed;
			}
			else
			{
				btn_search.Visibility = Visibility.Visible;
				btn_upload.Visibility = Visibility.Visible;
			}
		}

		private void btn_search_Click(object sender, RoutedEventArgs e)
		{
			MainWindow search_window = new MainWindow();
			search_window.Show();
			this.Close();
		}

		private void btn_upload_Click(object sender, RoutedEventArgs e)
		{
			ReceptHozzaadasWindow receptHozzadas_window = new ReceptHozzaadasWindow();
			receptHozzadas_window.Show();
			this.Close();
		}

		private void btn_navToMain_Click(object sender, RoutedEventArgs e)
		{
			MainWindow search_window = new MainWindow();
			search_window.Show();
			this.Close();
		}

		private void bt_NavToOpinion_Click(object sender, RoutedEventArgs e)
		{
			VelemenyWindow velemeny = new VelemenyWindow(bereceptNeve,befelhasznaloNeve);
			velemeny.Show();
        }

		private void btn_exit_Click(object sender, RoutedEventArgs e)
		{
			Application.Current.Shutdown();
		}
	}
}
