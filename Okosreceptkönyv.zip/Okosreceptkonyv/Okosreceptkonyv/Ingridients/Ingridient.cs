﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Okosreceptkonyv.Ingridients
{
    internal class Ingridient
    {
        public int ID { get; set; }
        public string Nev { get; set; }
    }
}
