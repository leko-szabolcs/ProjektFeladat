﻿using Okosreceptkonyv.Connection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Dapper;
using Okosreceptkonyv.Connection;
using Okosreceptkonyv.Users;

namespace Okosreceptkonyv
{
    /// <summary>
    /// Interaction logic for BejelentkezesWindow.xaml
    /// </summary>
    public partial class BejelentkezesWindow : Window
    {
		public BejelentkezesWindow()
        {
            InitializeComponent();
        }

		private void btn_navToMain_Click(object sender, RoutedEventArgs e)
		{
            MainWindow main_felulet = new MainWindow();
            main_felulet.Show();
            this.Close();
		}


		private void btn_nouser_Click(object sender, RoutedEventArgs e)
		{
            RegisztracioWindow regisztracios_felulet = new RegisztracioWindow();
            regisztracios_felulet.Show();
            this.Close();
		}

		private void btn_search_Click(object sender, RoutedEventArgs e)
		{
			MainWindow search_window = new MainWindow();
			search_window.Show();
			this.Close();
		}

		private void btn_upload_Click(object sender, RoutedEventArgs e)
		{
			ReceptHozzaadasWindow receptHozzadas_window = new ReceptHozzaadasWindow();
			receptHozzadas_window.Show();
			this.Close();
		}

		private void btn_navigation_Click(object sender, RoutedEventArgs e)
		{
			if (btn_search.Visibility == Visibility.Visible && btn_upload.Visibility == Visibility.Visible)
			{
				btn_search.Visibility = Visibility.Collapsed;
				btn_upload.Visibility = Visibility.Collapsed;
			}
			else
			{
				btn_search.Visibility = Visibility.Visible;
				btn_upload.Visibility = Visibility.Visible;
			}

		}

        private void btn_Belepes_Click(object sender, RoutedEventArgs e)
        {
            using (var kapcsolat = connection.GetDbConnection())
            {
                var felhasznalo = kapcsolat.QueryFirstOrDefault<User>("USE okosrecetkonyv SELECT * FROM FELHASZNALO WHERE Nev = @Nev AND Jelszo = @Jelszo AND Aktiv = 1",
                                        new { Nev = tb_username.Text.ToString(), Jelszo = pb_password.Password });

                if (felhasznalo != null)
                {
					UserSession.IsLoggedIn = true;
                    UserSession.UserName = felhasznalo.Nev;
					//DialogResult = true;
					MainWindow main_felulet = new MainWindow();
                    main_felulet.Show();
                    this.Close();
                }
                else
                {
					tb_username.Text = "";
                    pb_password.Password = "";
                    MessageBox.Show("Hibás felhasználói adatok!", "Belépési Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }


        }
        private void tb_username_GotFocus(object sender, RoutedEventArgs e)
        {
            if (tb_username.Text == "Felhasználónév")
            {
                tb_username.Text = "";
            }
        }

        private void pb_password_GotFocus(object sender, RoutedEventArgs e)
        {
            if (pb_password.Password == "jelszó")
            {
                pb_password.Password = "";
            }
        }

        private void tb_username_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_username.Text))
            {
                tb_username.Text = "Felhasználónév";
            }
        }

        private void pb_password_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(pb_password.Password))
            {
                pb_password.Password = "jelszó";
            }
        }

		private void btn_exit_Click(object sender, RoutedEventArgs e)
		{
            Application.Current.Shutdown();
        }
    }
}
