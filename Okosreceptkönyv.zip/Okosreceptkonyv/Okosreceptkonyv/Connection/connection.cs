﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace Okosreceptkonyv.Connection
{
    public class connection
    {

        private static string GetConStr()
        {
            var conStr = System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            return conStr;
        }

        public static DbConnection GetDbConnection()
        {
            var conn = new SqlConnection(GetConStr());
            conn.Open();

            return conn;
        }


    }
}
