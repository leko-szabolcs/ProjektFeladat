﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using Dapper;
using Okosreceptkonyv.Connection;
using Okosreceptkonyv.Users;
using Okosreceptkonyv.Recipes;
using System.Data;
using System.Collections.ObjectModel;
using Microsoft.Data.SqlClient;
using Okosreceptkonyv.UnitsOfMeasure;

namespace Okosreceptkonyv
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //Dinamikusan változó lista létrehozása
        public ObservableCollection<Recipe> receptnevLista;

		List<string> ingridients_list = new List<string>();
		List<int> ingridients_unit_quantity_list = new List<int>();
		List<int> ingridients_unit_id_list = new List<int>();
		List<string> ingridients_add_list = new List<string>();
		List<string> categories_list;
		List<int> categories_id_list;
		List<string> unitofmeasure_list;
		List<int> unitofmeasure_id_list;

		public MainWindow()
        {
            InitializeComponent();
            receptnevLista = new ObservableCollection<Recipe>();
            lwsearch.ItemsSource = receptnevLista;

            using (var kapcsolat = connection.GetDbConnection())
            {
                var mertekegysegek = kapcsolat.Query<UnitOfMeasure>("USE okosrecetkonyv select * from [MERTEKEGYSEG]");
                unitofmeasure_id_list = new List<int>();
                unitofmeasure_list = new List<string>();
                foreach (var unitofmeasure in mertekegysegek)
                {
                    unitofmeasure_id_list.Add(unitofmeasure.ID);
                    unitofmeasure_list.Add(unitofmeasure.Nev);
                }
                dropdownComboBox.ItemsSource = unitofmeasure_list;
            }
        }

        private void btn_user_Click(object sender, RoutedEventArgs e)
        {
			if (UserSession.IsLoggedIn)
			{
				btn_logout.Visibility = Visibility.Visible;
			}
			else
			{
				BejelentkezesWindow bej_felulet = new BejelentkezesWindow();
				bej_felulet.ShowDialog();
				if (bej_felulet.DialogResult.HasValue && bej_felulet.DialogResult.Value)
				{
					UserSession.IsLoggedIn = true;
					btn_logout.Visibility = Visibility.Visible;
				}
			}
		}

        public void display_results(String beirtszoveg)
        {
            using (var kapcsolat = connection.GetDbConnection())
            {

                //DynamicParameters objektumhoz hozzáadjuk paraméterként a keresőbe beírt szöveget
                DynamicParameters parameterek = new DynamicParameters();
                parameterek.Add("receptnev", beirtszoveg);

                DynamicParameters parameterek2 = new DynamicParameters();
                parameterek2.Add("kategorianev", beirtszoveg);


                string useDatabaseQuery = "USE okosrecetkonyv;";
                SqlCommand useDatabaseCommand = new SqlCommand(useDatabaseQuery, (SqlConnection)kapcsolat);
                useDatabaseCommand.ExecuteNonQuery();

                //Végrehajtjuk a tárolt eljárást és hozzárendeljük az eljárás kimenetelét a talalatRecNev-hez, receptnév alapján keres
                var talalatRecNev = kapcsolat.Query<Recipe>("GetRecipeNames", parameterek, commandType: CommandType.StoredProcedure);
                //Végrehajtjuk a tárolt eljárást és hozzárendeljük az eljárás kimenetelét a talalatKatAlapjan-hez, kategórianév alapján keres
                var talalatKatAlapjan = kapcsolat.Query<Recipe>("GetRecipeNamesByCategory", parameterek2, commandType: CommandType.StoredProcedure);



                //Megvizsgáljuk, hogy a receptnévre és kategóriára keresés üres eredményt adott-e vissza
                bool isEmptyRN = !talalatRecNev.Any();
                bool isEmptyRNBC = !talalatKatAlapjan.Any();

                //Megvizsgáljuk a két féle keresés lehetséges kimeneteleit és az alapján íratjuk ki a találatokat.        
                if (isEmptyRN == true && isEmptyRNBC == true)//Egyik féle keresés se adott találatot
                {
                    MessageBox.Show("Nincs a keresésnek megfelelő találat az adatbázisban!", "Keresési Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else if (isEmptyRN == false && isEmptyRNBC == false)//Mindkét féle keresés találatot adott
                {
                    DynamicParameters parameterek3 = new DynamicParameters();
                    parameterek3.Add("megadottszoveg", beirtszoveg);
                    var duplaKeresesTalalat = kapcsolat.Query<Recipe>("GetRecipeByNameAndCat", parameterek3, commandType: CommandType.StoredProcedure);

                    foreach (var talalat in duplaKeresesTalalat)
                    {

                        receptnevLista.Add(new Recipe() { Kep_ID = talalat.Kep_ID, Nev = talalat.Nev });
                    }
                }
                //Kategóriára keresünk rá és nincs receptnévre is találat
                else if (isEmptyRN == true && isEmptyRNBC == false)
                {
                    foreach (var talalat in talalatKatAlapjan)
                    {

                        receptnevLista.Add(new Recipe() { Kep_ID = talalat.Kep_ID, Nev = talalat.Nev });
                    }
                }
                //Receptnévre keresünk rá és nincs kategóriára is találat
                else if (isEmptyRN == false && isEmptyRNBC == true)
                {
                    foreach (var talalat in talalatRecNev)
                    {

                        receptnevLista.Add(new Recipe() { Kep_ID = talalat.Kep_ID, Nev = talalat.Nev });
                    }
                }


            }
        }
        

            private void OnKeyDownHandler(object sender, KeyEventArgs e)
            {
                // Ha lenyomtuk az entert
                if (e.Key == Key.Return)
                {
                    //Minden enter lenyomásakor törli az esetleges elemeket a ListView-ból, hogy az új
                    //keresések kerüljenek megelenítésre.
                    //lwsearch.ClearValue(ListView.ItemsSourceProperty);
                    receptnevLista.Clear();

                    if (String.IsNullOrEmpty(tbsearch.Text))
                    {
                        MessageBox.Show("Kérlek adj meg egy receptnevet a kereséshez!", "Keresési Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        String beirtszoveg = tbsearch.Text.ToString();
                        display_results(beirtszoveg);


                    }
                }

            }

        private void displayResultsByIngredients(List<string> ingridients_list)
        {
            
            if (!ingridients_list.Any())
            {
                // Ha az ingredientsList üres, akkor kilépünk a metódusból
                return;
            }
            else
            {
                //lwsearch.ClearValue(ListView.ItemsSourceProperty);

                var parameterek = new DynamicParameters();

                
                String szovegparam = ingridients_list[0];
                for (int i = 1; i < ingridients_list.Count; i++)
                {
                    szovegparam = szovegparam + "," + ingridients_list[i];
                }

                parameterek.Add("hozzavalonev", szovegparam);

                using (var kapcsolat = connection.GetDbConnection())
                {
                    string useDatabaseQuery = "USE okosrecetkonyv;";
                    SqlCommand useDatabaseCommand = new SqlCommand(useDatabaseQuery, (SqlConnection)kapcsolat);
                    useDatabaseCommand.ExecuteNonQuery();
                    
                    var result = kapcsolat.Query<Recipe>("GetSearchRecipesByIngredients", parameterek, commandType: CommandType.StoredProcedure);
                    bool isEmptyResult = !result.Any();
                    if (isEmptyResult != true)
                    {
                        foreach (var talalat in result)
                        {

                            receptnevLista.Add(new Recipe() { Kep_ID = talalat.Kep_ID, Nev = talalat.Nev });
                        }
                        

                    }
                    else {
                        MessageBox.Show("Nincs találat!", "Keresés", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
             }
        }

        

        //navigáció
        private void btn_navigation_Click(object sender, RoutedEventArgs e)
        {
            if (btn_search.Visibility == Visibility.Visible && btn_upload.Visibility == Visibility.Visible)
            {
                btn_search.Visibility = Visibility.Collapsed;
                btn_upload.Visibility = Visibility.Collapsed;
            }
            else
            {
                btn_search.Visibility = Visibility.Visible;
                btn_upload.Visibility = Visibility.Visible;
            }
        }

        private void btn_upload_Click(object sender, RoutedEventArgs e)
        {
            ReceptHozzaadasWindow receptHozzadas_window = new ReceptHozzaadasWindow();
            receptHozzadas_window.Show();
            this.Close();
        }

        private void btn_search_Click(object sender, RoutedEventArgs e)
        {
            MainWindow search_window = new MainWindow();
            search_window.Show();
            this.Close();
        }

        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btn_ingridient_Click(object sender, RoutedEventArgs e)
        {
			if (ingridient_border.Visibility != Visibility.Visible)
			{
				ingridient_border.Visibility = Visibility.Visible;
			}
			else
			{
				tb_quantity.Text = "Mennyiség"; dropdownComboBox.SelectedItem = null; tb_ingridient.Text = "Hozzávaló neve";
				ingridient_border.Visibility = Visibility.Hidden;
			}
		}

        private void btn_filter_Click(object sender, RoutedEventArgs e)
        {
            if (ingridients.Visibility == Visibility.Visible)
            {
                ingridients.Visibility = Visibility.Collapsed;
            }
            else
            {
                ingridients.Visibility = Visibility.Visible;
            }
        }

		private void btn_logout_Click(object sender, RoutedEventArgs e)
		{
            // Perform logout action
            UserSession.IsLoggedIn = false;
            UserSession.UserName= null;
			// Hide logout button
			btn_logout.Visibility = Visibility.Collapsed;
		}

		private void btn_close_Click(object sender, RoutedEventArgs e)
		{
			tb_quantity.Text = ""; dropdownComboBox.SelectedItem = null; tb_ingridient.Text = "";
			ingridient_border.Visibility = Visibility.Hidden;
		}

		private void btn_add_ingridient_Click(object sender, RoutedEventArgs e)
		{
           

            if (tb_ingridient.Text == "" || int.TryParse(tb_ingridient.Text, out _) || ingridients_list.Contains(tb_ingridient.Text))
			{
				System.Windows.MessageBox.Show("Adjon meg nevet a hozzávalóhoz!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
			}
			else if (tb_quantity.Text == "" || !int.TryParse(tb_quantity.Text, out _))
			{
				System.Windows.MessageBox.Show("A mennyiség mező üres, vagy nem szám!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
			}
			else if (dropdownComboBox.SelectedItem == null)
			{
				System.Windows.MessageBox.Show("Nincs mértékegység kiválasztva!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
			}
			else
			{
				ingridients_add_list.Add(tb_quantity.Text + " " + dropdownComboBox.SelectedItem.ToString() + " " + tb_ingridient.Text.ToLower());
				ingidient_list.ItemsSource = ingridients_add_list;
				ingidient_list.Items.Refresh();
				ingridients_list.Add(tb_ingridient.Text.ToLower());
				ingridients_unit_quantity_list.Add(int.Parse(tb_quantity.Text));
				ingridients_unit_id_list.Add(unitofmeasure_id_list[unitofmeasure_list.IndexOf(dropdownComboBox.SelectedItem.ToString())]);
				tb_quantity.Text = ""; dropdownComboBox.SelectedItem = null; tb_ingridient.Text = "";
				ingridient_border.Visibility = Visibility.Hidden;

                //ingridients_list hozzávalók listája a kereséshez
                //MessageBox.Show("Hozzávalók:", "Keresési Hiba", MessageBoxButton.OK, MessageBoxImage.Error);

                receptnevLista.Clear();
                displayResultsByIngredients(ingridients_list);
                
            }
        }

        private void tbSearchGotFocus(object sender, RoutedEventArgs e)
        {
            ingridients_add_list.Clear();
            ingidient_list.Items.Refresh();
        }

        private void navigateRecept(object sender, SelectionChangedEventArgs e)
        {
            if(UserSession.UserName==null)
            {
                UserSession.UserName = "Admin";
            }
            ReceptWindow receptWindow = new ReceptWindow(receptnevLista[lwsearch.SelectedIndex].Nev, UserSession.UserName);
            // System.Windows.MessageBox.Show("Működik" + receptnevLista[lwsearch.SelectedIndex].Nev, "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            receptWindow.Show();
            this.Close();
        }




    }
}
