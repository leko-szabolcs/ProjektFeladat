﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Okosreceptkonyv.Connection;
using Dapper;
using System.Data.SqlClient;
using static Okosreceptkonyv.ReceptWindow;

namespace Okosreceptkonyv
{
	/// <summary>
	/// Interaction logic for VelemenyWindow.xaml
	/// </summary>
	public partial class VelemenyWindow : Window
	{
        public String bereceptNeve;
        public String befelhasznaloNev;

        public VelemenyWindow(String receptNev, String felhasznaloNev)
		{
			InitializeComponent();
            bereceptNeve = receptNev;
            befelhasznaloNev = felhasznaloNev;
        }

		private void ToggleButton_Click(object sender, RoutedEventArgs e)
		{

            string felhasznaloNev = befelhasznaloNev;
            string receptNev = bereceptNeve;

            int felhasznaloId = GetFelhasznaloId(felhasznaloNev);
            int receptId = GetReceptId(receptNev);

            if (felhasznaloId != 0 && receptId != 0)
            {
                Velemeny velemeny = new Velemeny
                {
                    Felhasznalo_ID = felhasznaloId,
                    Recept_ID = receptId,
                    Ertekeles = sl_opinion.Value
                };

                SaveVelemeny(velemeny);
            }
            ReceptWindow recept_window = new ReceptWindow(bereceptNeve, befelhasznaloNev);
            recept_window.Show();
            this.Close();
		}

        public void SaveVelemeny(Velemeny velemeny)
        {
                using (var kapcsolat = connection.GetDbConnection())
                {
                    string insertQuery = @"use Okosrecetkonyv INSERT INTO ERTEKELES (Felhasznalo_ID, Recept_ID, Ertekeles) VALUES (@Felhasznalo_ID, @Recept_ID, @Ertekeles);";

                    SqlCommand command = new SqlCommand(insertQuery, (SqlConnection)kapcsolat);
                    command.Parameters.AddWithValue("@Felhasznalo_ID", velemeny.Felhasznalo_ID);
                    command.Parameters.AddWithValue("@Recept_ID", velemeny.Recept_ID);
                    command.Parameters.AddWithValue("@Ertekeles", velemeny.Ertekeles);

                    //kapcsolat.Open();
                    int affectedRows = command.ExecuteNonQuery();

                    if (affectedRows > 0)
                    {
                        MessageBox.Show("Vélemény sikeresen mentve!");
                    }
                    else
                    {
                        MessageBox.Show("A mentés nem sikerült!");
                    }
                }
        }

        private int GetFelhasznaloId(string felhasznaloNev)
        {
            int felhasznaloId = 0;

            using (var kapcsolat = connection.GetDbConnection())
            {
                string query = "Use Okosrecetkonyv SELECT ID FROM FELHASZNALO WHERE Nev = @Nev";

                using (var command = new SqlCommand(query, (SqlConnection)kapcsolat))
                {
                    command.Parameters.AddWithValue("@Nev", felhasznaloNev);

                    //kapcsolat.Open();
                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        felhasznaloId = Convert.ToInt32(result);
                    }
                }
            }

            return felhasznaloId;
        }

        private int GetReceptId(string receptNev)
        {
            int receptId = 0;

            using (var kapcsolat = connection.GetDbConnection())
            {
                string query = "use Okosrecetkonyv SELECT ID FROM RECEPT WHERE Nev = @Nev";

                using (var command = new SqlCommand(query, (SqlConnection)kapcsolat))
                {
                    command.Parameters.AddWithValue("@Nev", receptNev);

                    //kapcsolat.Open();
                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        receptId = Convert.ToInt32(result);
                    }
                }
            }

            return receptId;
        }

        public class Velemeny
        {
            public int Felhasznalo_ID { get; set; }
            public int Recept_ID { get; set; }
            public double Ertekeles { get; set; }
        }


    }
}
