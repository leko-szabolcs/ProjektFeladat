﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Okosreceptkonyv.Recipes
{
    public class Recipe
    {
        public int ID { get; set; }
        public int Kep_ID { get; set; }
        public string Nev { get; set; }
        public string Leiras { get; set; }
        
    }
}
